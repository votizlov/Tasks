﻿using System;
using System.Timers;
using System.Windows;
using System.Windows.Controls;

namespace Task7
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
    }
}